#   GNU GPLv3
#   <this is an add-on Script/Macro for the geospatial software "Trimble Business Center" aka TBC>
#   <you'll need at least the "Survey Advanced" licence of TBC in order to run this script>
#	<see the ToolTip section below for a brief explanation what the script does>
#	<see the Help-Files for more details>
#   Copyright (C) 2023 Ronny Schneider
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <https://www.gnu.org/licenses/>

from System.Collections.Generic import List, IEnumerable # import here, otherwise there is a weird issue with Count and Add for lists
import os
exec(open("C:\ProgramData\Trimble\MacroCommands3\SCR Macros\SCR_Imports.py").read())

def Setup(cmdData, macroFileFolder):
    cmdData.Key = "SCR_SelectPtsOffLine"
    cmdData.CommandName = "SCR_SelectPtsOffLine"
    cmdData.Caption = "_SCR_SelectPtsOffLine"
    cmdData.UIForm = "SCR_SelectPtsOffLine"      # MUST MATCH NAME FROM CLASS DEFINED BELOW !!!
    cmdData.HelpFile = "Macros.chm"
    cmdData.HelpTopic = "22602"

    try:
        cmdData.DefaultTabKey = "SCR Lines/Points"
        cmdData.DefaultTabGroupKey = "Points"
        cmdData.ShortCaption = "Select Points Off Line"
        cmdData.DefaultRibbonToolSize = 3 # Default=0, ImageOnly=1, Normal=2, Large=3

        cmdData.Version = 1.05
        cmdData.MacroAuthor = "SCR"
        cmdData.MacroInfo = r""
        
        cmdData.ToolTipTitle = "Select Points Off Line"
        cmdData.ToolTipTextFormatted = "Select Points Off Line"

    except:
        pass
    try:
        b = Bitmap (macroFileFolder + "\\" + cmdData.Key + ".png")
        cmdData.ImageSmall = b
    except:
        pass


class SCR_SelectPtsOffLine(StackPanel): # this inherits from the WPF StackPanel control
    def __init__(self, currentProject, macroFileFolder):
        with StreamReader (macroFileFolder + r"\SCR_SelectPtsOffLine.xaml") as s:
            wpf.LoadComponent (self, s)
        self.currentProject = currentProject
        self.macroFileFolder = macroFileFolder

    def HelpClicked(self, cmd, e):
        webbrowser.open("C:\ProgramData\Trimble\MacroCommands3\SCR Macros\MacroHelp\MacroHelp.htm#" + type(self).__name__)


    def OnLoad(self, cmd, buttons, event):
        self.okBtn = buttons[0]
        buttons[2].Content = "Help"
        buttons[2].Visibility = Visibility.Visible
        buttons[2].Click += self.HelpClicked
        self.Caption = cmd.Command.Caption
        #types = Array [Type] ([CadPoint]) + Array [Type] ([Point3D])    # we fill an array with TBC object types, we could combine different types
        self.linepicker1.IsEntityValidCallback = self.IsValid
        
        self.lType = clr.GetClrType(IPolyseg)

		# after changing the input fields in a lot of macros from the old textboxes to floating point number or distance edits
		# it could happen that old settings, saved as strings, would throw a type cast error
		# hence it's better to have it in a try block
        try:
            self.SetDefaultOptions()
        except:
            pass

        self.linepicker1.ValueChanged += self.lineChanged
        self.linepicker1.AutoTab = False

    def lineChanged(self, ctrl, e):
        self.OkClicked(None, None)
        
   

    def SetDefaultOptions(self):
        pass

    def SaveOptions(self):
        pass
    
    def IsValid(self, serial):
        o = self.currentProject.Concordance.Lookup(serial)
        if isinstance(o, self.lType):
            return True
        return False



    def CancelClicked(self, cmd, args):
        cmd.CloseUICommand ()


    def OkClicked(self, cmd, e):
        Keyboard.Focus(self.okBtn)
        self.error.Content=''
        self.success.Content = ''

        #self.currentProject.TransactionManager.AddBeginMark(CommandGranularity.Command, self.Caption)
        #UIEvents.RaiseBeforeDataProcessing(self, UIEventArgs())
        wv = self.currentProject [Project.FixedSerial.WorldView]
        #wv.PauseGraphicsCache(True)

        # get the units for linear distance
        self.lunits = self.currentProject.Units.Linear
        # we don't want the units to be included (so we make copy and turn that off). Otherwise get something like "12.50 ft"
        self.lfp = self.lunits.Properties.Copy()
        self.lfp.AddSuffix = False

        inputok = True
        l1 = self.linepicker1.Entity
        if l1==None: 
            self.success.Content += '\nno Line 1 selected'
            inputok=False
        if not isinstance(l1, Linestring):
            self.success.Content += '\nwrong Linetype'
            inputok=False
        
        if inputok:
   
            # the "with" statement will unroll any changes if something go wrong
            #with TransactMethodCall(self.currentProject.TransactionCollector) as failGuard:
            filename = os.path.expanduser('~/Downloads/Node-Output.csv')
            if File.Exists(filename):
                File.Delete(filename)
            with open(filename, 'w') as f:            

                newselection = []

                #find PointManager as object
                for o in self.currentProject:
                    if isinstance(o, PointManager):
                        pm = o
                #find RawDataContainer as object
                for o in wv:
                    if isinstance(o, RawDataContainer):
                        rdc = o

                linenodes = self.currentProject.Concordance.Lookup(self.linepicker1.SerialNumber).GetElements()
                
                ProgressBar.TBC_ProgressBar.Title = "checking " + str(linenodes.Count) + " line nodes against " + str(rdc.AllPoints.Count) + " database points"
                i = 0
                rdclastfoundindex = 0
                for node in linenodes:
                    i += 1
                    if ProgressBar.TBC_ProgressBar.SetProgress(math.floor(i * 100 / linenodes.Count)):
                        break   # function returns true if user pressed cancel

                    outputline = ''
                    try:
                        node_location = self.currentProject.Concordance.Lookup(node.LocationSerialNumber)
                        newselection.Add(node.LocationSerialNumber)
                        outputline = node_location.AnchorName

                        
                        outputline += ',' + self.lunits.Format(self.lunits.Convert(node_location.AnchorPoint.X, LinearType.Display), self.lfp)
                        outputline += ',' + self.lunits.Format(self.lunits.Convert(node_location.AnchorPoint.Y, LinearType.Display), self.lfp)
                        outputline += ',' + self.lunits.Format(self.lunits.Convert(node_location.AnchorPoint.Z, LinearType.Display), self.lfp)
                        if pm.AssociatedRDFeatures(node.LocationSerialNumber).Count > 0:
                            attr_list = pm.AssociatedRDFeatures(node.LocationSerialNumber)[0].Attributes
                            if attr_list.Count > 0:
                                for att in attr_list:
                                    outputline += ',' + str(att.Name) + ":" + str(att.Value)
                    except: # if it's a node that is just a coordinate

                        # new algorithm in order to reduce search time
                        # tries to avoid going through the whole points list from the start each time
                        # points along a line are often more or less consecutive and should be closeby in the points list
                        # the algorithm uses the last point index as seed fo the next one
                        # and increments up and down from there

                        foundpoint = False
                        pointstested = 0
                        searchinc = 0
                        rdctestindex = rdclastfoundindex + searchinc
                        while pointstested < rdc.AllPoints.Count:
                            pserial = rdc.AllPoints[rdctestindex]   # go through all the point serials in the RawDataContainer
                            rdc_point = self.currentProject.Concordance.Lookup(pserial) # get the point object via its serial number
                            if Vector3D(rdc_point.AnchorPoint, node.Position).Length == 0:
                                newselection.Add(pserial)

                                outputline = "??? " + rdc_point.AnchorName
                                outputline += ',' + self.lunits.Format(self.lunits.Convert(rdc_point.AnchorPoint.X, LinearType.Display), self.lfp)
                                outputline += ',' + self.lunits.Format(self.lunits.Convert(rdc_point.AnchorPoint.Y, LinearType.Display), self.lfp)
                                outputline += ',' + self.lunits.Format(self.lunits.Convert(rdc_point.AnchorPoint.Z, LinearType.Display), self.lfp)
                                if pm.AssociatedRDFeatures(pserial).Count > 0:
                                    attr_list = pm.AssociatedRDFeatures(pserial)[0].Attributes
                                    if attr_list.Count > 0:
                                        for att in attr_list:
                                            outputline += ',' + str(att.Name) + ":" + str(att.Value)
                                outputline += ' ???'

                                foundpoint = True
                                rdclastfoundindex = rdctestindex
                                break

                            pointstested += 1

                            if searchinc > 0:
                                searchinc = -1 * searchinc
                            elif searchinc <= 0:
                                searchinc = (-1 * searchinc) + 1

                            rdctestindex = rdclastfoundindex + searchinc
                            if rdctestindex < 0:
                                rdctestindex += rdc.AllPoints.Count
                            if rdctestindex >= rdc.AllPoints.Count:
                                rdctestindex -= rdc.AllPoints.Count

                        if foundpoint == False:
                            outputline += '!!! Linevertex without DB-Point'
                            
                            outputline += ',' + self.lunits.Format(self.lunits.Convert(node.Position.X, LinearType.Display), self.lfp)
                            outputline += ',' + self.lunits.Format(self.lunits.Convert(node.Position.Y, LinearType.Display), self.lfp)
                            outputline += ',' + self.lunits.Format(self.lunits.Convert(node.Position.Z, LinearType.Display), self.lfp)
                            outputline += ' !!!'


                    self.success.Content += outputline + "\n"
                    f.write(outputline + "\n")
                    
                    
                f.close()
                GlobalSelection.Items(self.currentProject).Set(newselection)

            #failGuard.Commit()
            self.success.Content += '\n\nResult also written to:\n'
            self.success.Content += str(filename)


        #self.currentProject.TransactionManager.AddEndMark(CommandGranularity.Command)
        #UIEvents.RaiseAfterDataProcessing(self, UIEventArgs())

        self.success.Content += '\n\nDone'
        self.SaveOptions()
        ProgressBar.TBC_ProgressBar.Title = ""
        Keyboard.Focus(self.linepicker1)
