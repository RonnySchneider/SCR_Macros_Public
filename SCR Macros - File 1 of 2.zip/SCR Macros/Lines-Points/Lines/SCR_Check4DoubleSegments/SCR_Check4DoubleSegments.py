#   GNU GPLv3
#   <this is an add-on Script/Macro for the geospatial software "Trimble Business Center" aka TBC>
#   <you'll need at least the "Survey Advanced" licence of TBC in order to run this script>
#	<see the ToolTip section below for a brief explanation what the script does>
#	<see the Help-Files for more details>
#   Copyright (C) 2023 Ronny Schneider
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <https://www.gnu.org/licenses/>

from System.Collections.Generic import List, IEnumerable # import here, otherwise there is a weird issue with Count and Add for lists
import os
exec(open("C:\ProgramData\Trimble\MacroCommands3\SCR Macros\SCR_Imports.py").read())

def Setup(cmdData, macroFileFolder):
    cmdData.Key = "SCR_Check4DoubleSegments"
    cmdData.CommandName = "SCR_Check4DoubleSegments"
    cmdData.Caption = "_SCR_Check4DoubleSegments"
    cmdData.UIForm = "SCR_Check4DoubleSegments"      # MUST MATCH NAME FROM CLASS DEFINED BELOW !!!
    cmdData.HelpFile = "Macros.chm"
    cmdData.HelpTopic = "22602"

    try:
        cmdData.DefaultTabKey = "SCR Lines/Points"
        cmdData.DefaultTabGroupKey = "Lines"
        cmdData.ShortCaption = "Check4DoubleSegments"
        cmdData.DefaultRibbonToolSize = 3 # Default=0, ImageOnly=1, Normal=2, Large=3

        cmdData.Version = 1.05
        cmdData.MacroAuthor = "SCR"
        cmdData.MacroInfo = r""
        
        cmdData.ToolTipTitle = "check for duplicate Segments"
        cmdData.ToolTipTextFormatted = "check for duplicate Segments"

    except:
        pass
    try:
        b = Bitmap (macroFileFolder + "\\" + cmdData.Key + ".png")
        cmdData.ImageSmall = b
    except:
        pass


class SCR_Check4DoubleSegments(StackPanel): # this inherits from the WPF StackPanel control
    def __init__(self, currentProject, macroFileFolder):
        with StreamReader (macroFileFolder + r"\SCR_Check4DoubleSegments.xaml") as s:
            wpf.LoadComponent (self, s)
        self.currentProject = currentProject
        self.macroFileFolder = macroFileFolder

    def HelpClicked(self, cmd, e):
        webbrowser.open("C:\ProgramData\Trimble\MacroCommands3\SCR Macros\MacroHelp\MacroHelp.htm#" + type(self).__name__)


    def OnLoad(self, cmd, buttons, event):
        self.okBtn = buttons[0]
        buttons[2].Content = "Help"
        buttons[2].Visibility = Visibility.Visible
        buttons[2].Click += self.HelpClicked
        self.Caption = cmd.Command.Caption


        #self.lType = clr.GetClrType(IPolyseg)
        self.lType = clr.GetClrType(Linestring)

        self.objs.IsEntityValidCallback = self.IsValid

        self.hztol.DistanceMin = 0.00000001
        self.hztol.DistanceMax = 0.9999999
        self.vztol.DistanceMin = 0.00000001
        self.vztol.DistanceMax = 0.9999999
        
        self.vztol.DistanceType = DistanceType.Z


        # get the units for linear distance
        self.lunits = self.currentProject.Units.Linear
        #self.lfp = self.lunits.Properties.Copy()
        linearsuffix = self.lunits.Units[self.lunits.DisplayType].Abbreviation
        #self.lfp.AddSuffix = False
        self.hztollabel.Content = "horizontal tolerance [" + linearsuffix + "] <="
        self.vztollabel.Content = "vertical tolerance [" + linearsuffix + "] <="


        self.SetDefaultOptions()

    def IsValid(self, serial):
        o = self.currentProject.Concordance.Lookup(serial)
        if isinstance(o, self.lType):
            return True
        return False


    def SetDefaultOptions(self):

        # layer
        lserial = OptionsManager.GetUint("SCR_Check4DoubleSegments.layerpicker", 8)
        o = self.currentProject.Concordance.Lookup(lserial)
        if o != None:
            if isinstance(o.GetSite(), LayerCollection):    
                self.layerpicker.SetSelectedSerialNumber(lserial, InputMethod(3))
            else:                       
                self.layerpicker.SetSelectedSerialNumber(8, InputMethod(3))
        else:                       
            self.layerpicker.SetSelectedSerialNumber(8, InputMethod(3))

        self.hztol.Distance = OptionsManager.GetDouble("SCR_Check4DoubleSegments.hztol", 0.0010)
        self.vztol.Distance = OptionsManager.GetDouble("SCR_Check4DoubleSegments.vztol", 0.0010)

        self.highlightmode.IsChecked = OptionsManager.GetBool("SCR_Check4DoubleSegments.highlightmode", True)
        self.deletemode.IsChecked = OptionsManager.GetBool("SCR_Check4DoubleSegments.deletemode", False)

    def SaveOptions(self):

        OptionsManager.SetValue("SCR_Check4DoubleSegments.layerpicker", self.layerpicker.SelectedSerialNumber)

        OptionsManager.SetValue("SCR_Check4DoubleSegments.hztol", self.hztol.Distance)
        OptionsManager.SetValue("SCR_Check4DoubleSegments.vztol", self.vztol.Distance)

        OptionsManager.SetValue("SCR_Check4DoubleSegments.highlightmode", self.highlightmode.IsChecked) 
        OptionsManager.SetValue("SCR_Check4DoubleSegments.deletemode", self.deletemode.IsChecked) 

    def CancelClicked(self, cmd, args):
        cmd.CloseUICommand ()

    def OkClicked(self, cmd, e):

        Keyboard.Focus(self.okBtn)
        self.error.Content=''
        self.success.Content = ''
        self.error3Dduplicate.Content = ''
        self.error2Dduplicate.Content = ''

        wv = self.currentProject [Project.FixedSerial.WorldView]
        wv.PauseGraphicsCache(True)

        self.currentProject.TransactionManager.AddBeginMark(CommandGranularity.Command, self.Caption)
        UIEvents.RaiseBeforeDataProcessing(self, UIEventArgs())
        try:
            with TransactMethodCall(self.currentProject.TransactionCollector) as failGuard:

                if self.deletemode.IsChecked:

                    # prepare tables
                    lineserials = []
                    self.lookupx = {}
                    self.lookupy = {}
                    self.lookupz = {}

                    #tt0 = '{:f}'.format(self.hztol.Distance)
                    #tt1 = len(search("\.(0*)", '{:f}'.format(self.hztol.Distance)).group(1)) + 1
                    #tt2 = '{:f}'.format(self.vztol.Distance)
                    #tt3 = len(search("\.(0*)", '{:f}'.format(self.vztol.Distance)).group(1)) + 1

                    truncdecimalshz = len(search("\.(0*)", '{:f}'.format(self.hztol.Distance)).group(1))
                    truncdecimalsvz = len(search("\.(0*)", '{:f}'.format(self.vztol.Distance)).group(1))

                    # need to add coord values to 2 dictionary keys - rounded up and down
                    # later during comparison the tolerance can go across a decimal place
                    # i.e tol               0.0002      0.009
                    #------------------------------------------
                    # coord point here/now  1.0979      1.0978
                    # later coord comp      1.0981      1.0981 - needs to find the above, if we simply truncate, we'll miss it
                    # need to add to keys
                    #                       1.097       1.09
                    #                       1.098       1.10
                    
                    #t1 = 1.0978
                    #t2 = 1.0981 
                    #
                    #tt1 = self.roundandtruncate(t1, truncdecimalshz, False)
                    #tt2 = self.roundandtruncate(t1, truncdecimalshz, True)

                   
                    time1 = datetime.now()
                    i1 = 0
                    ProgressBar.TBC_ProgressBar.Title = "preparing Lookup-Tables"
                    for o in self.objs:

                        i1 += 1
                        # reducing the number of times the progressbar is updated, could lead to serious slowdown
                        # 2% increments
                        #if (i1 * 100 // self.objs.Count) % 2 == 0:
                        #tt = datetime.now() - time1 # delivers .days .microseconds . seconds
                        if (datetime.now() - time1).seconds > 1:
                            if ProgressBar.TBC_ProgressBar.SetProgress(i1 * 100 // self.objs.Count):
                                break
                            time1 = datetime.now()

                        if isinstance(o, self.lType):                
                            if o.ElementCount == 2:

                                p1 = o.GetElementInWCS(0).Position
                                p2 = o.GetElementInWCS(1).Position

                                if p1.Is3D and p2.Is3D: # quick and dirty check if we have 2 3D points
                                    lineserials.Add([o.SerialNumber, p1, p2, False])

                                else:
                                    # try to get the information from the vertical polyseg
                                    # doesn't cover different segment types like curves
                                    # handles every line as if it's straight

                                    #polyseg1 = o.ComputePolySeg()
                                    #polyseg1 = polyseg1.ToWorld()
                                    polyseg1_v = o.ComputeVerticalPolySeg()

                                    p1.Z = polyseg1_v.FirstSegment.BeginPoint.Y
                                    p2.Z = polyseg1_v.FirstSegment.EndPoint.Y
                                    tt = 1

                                    if p1.Is3D and p2.Is3D: # quick and dirty check if we have 2 3D points
                                        lineserials.Add([o.SerialNumber, p1, p2, False])


                                # https://stackoverflow.com/questions/20585920/how-to-add-multiple-values-to-a-dictionary-key

                                # add index towards lineserials into coordinate lookup tables
                                # start - only add keys if they don't exist yet
                                keyx = self.roundandtruncate(p1.X, truncdecimalshz, True)
                                keyy = self.roundandtruncate(p1.Y, truncdecimalshz, True)
                                keyz = self.roundandtruncate(p1.Z, truncdecimalsvz, True)
                                if keyx not in self.lookupx: self.lookupx.update({keyx : {}})
                                if keyy not in self.lookupy: self.lookupy.update({keyy : {}})
                                if keyz not in self.lookupz: self.lookupz.update({keyz : {}})
                                if lineserials.Count - 1 not in self.lookupx[keyx]: self.lookupx[keyx].update({lineserials.Count - 1 : {}})
                                if lineserials.Count - 1 not in self.lookupy[keyy]: self.lookupy[keyy].update({lineserials.Count - 1 : {}})
                                if lineserials.Count - 1 not in self.lookupz[keyz]: self.lookupz[keyz].update({lineserials.Count - 1 : {}})
                                
                                keyx = self.roundandtruncate(p1.X, truncdecimalshz, False)
                                keyy = self.roundandtruncate(p1.Y, truncdecimalshz, False)
                                keyz = self.roundandtruncate(p1.Z, truncdecimalsvz, False)
                                if keyx not in self.lookupx: self.lookupx.update({keyx : {}})
                                if keyy not in self.lookupy: self.lookupy.update({keyy : {}})
                                if keyz not in self.lookupz: self.lookupz.update({keyz : {}})
                                if lineserials.Count - 1 not in self.lookupx[keyx]: self.lookupx[keyx].update({lineserials.Count - 1 : {}})
                                if lineserials.Count - 1 not in self.lookupy[keyy]: self.lookupy[keyy].update({lineserials.Count - 1 : {}})
                                if lineserials.Count - 1 not in self.lookupz[keyz]: self.lookupz[keyz].update({lineserials.Count - 1 : {}})

                                # end - only add keys if they don't exist yet
                                keyx = self.roundandtruncate(p2.X, truncdecimalshz, True)
                                keyy = self.roundandtruncate(p2.Y, truncdecimalshz, True)
                                keyz = self.roundandtruncate(p2.Z, truncdecimalsvz, True)
                                if keyx not in self.lookupx: self.lookupx.update({keyx : {}})
                                if keyy not in self.lookupy: self.lookupy.update({keyy : {}})
                                if keyz not in self.lookupz: self.lookupz.update({keyz : {}})
                                if lineserials.Count - 1 not in self.lookupx[keyx]: self.lookupx[keyx].update({lineserials.Count - 1 : {}})
                                if lineserials.Count - 1 not in self.lookupy[keyy]: self.lookupy[keyy].update({lineserials.Count - 1 : {}})
                                if lineserials.Count - 1 not in self.lookupz[keyz]: self.lookupz[keyz].update({lineserials.Count - 1 : {}})
                                
                                keyx = self.roundandtruncate(p2.X, truncdecimalshz, False)
                                keyy = self.roundandtruncate(p2.Y, truncdecimalshz, False)
                                keyz = self.roundandtruncate(p2.Z, truncdecimalsvz, False)
                                if keyx not in self.lookupx: self.lookupx.update({keyx : {}})
                                if keyy not in self.lookupy: self.lookupy.update({keyy : {}})
                                if keyz not in self.lookupz: self.lookupz.update({keyz : {}})
                                if lineserials.Count - 1 not in self.lookupx[keyx]: self.lookupx[keyx].update({lineserials.Count - 1 : {}})
                                if lineserials.Count - 1 not in self.lookupy[keyy]: self.lookupy[keyy].update({lineserials.Count - 1 : {}})
                                if lineserials.Count - 1 not in self.lookupz[keyz]: self.lookupz[keyz].update({lineserials.Count - 1 : {}})



                    ProgressBar.TBC_ProgressBar.Title = "checking for duplicates"
                    time1 = datetime.now()
                    for i1 in range(0, lineserials.Count - 1):
                        
                        # we don't need to run checks if the line has been marked as delete already
                        if lineserials[i1][3] == True:
                            continue

                        # reducing the number of times the progressbar is updated, could lead to serious slowdown
                        # 2% increments
                        #if (i1 * 100 // lineserials.Count) % 2 == 0:
                        #tt = datetime.now() - time1 # delivers .days .microseconds . seconds
                        if (datetime.now() - time1).seconds > 1:
                            if ProgressBar.TBC_ProgressBar.SetProgress(i1 * 100 // lineserials.Count):
                                break
                            time1 = datetime.now()

                        # use the lookup table to find lineserials where the start and end are nearby
                        try:
                            # we can AND the xyz values and only add to the set if the search coordinate is found for all three
                            set1 =  set(self.lookupx[self.roundandtruncate(lineserials[i1][1].X, truncdecimalshz, False)]) & \
                                    set(self.lookupy[self.roundandtruncate(lineserials[i1][1].Y, truncdecimalshz, False)]) & \
                                    set(self.lookupz[self.roundandtruncate(lineserials[i1][1].Z, truncdecimalsvz, False)])
                                                                                                                      
                            set2 =  set(self.lookupx[self.roundandtruncate(lineserials[i1][1].X, truncdecimalshz,  True)]) & \
                                    set(self.lookupy[self.roundandtruncate(lineserials[i1][1].Y, truncdecimalshz,  True)]) & \
                                    set(self.lookupz[self.roundandtruncate(lineserials[i1][1].Z, truncdecimalsvz,  True)]) 

                            set3 =  set(self.lookupx[self.roundandtruncate(lineserials[i1][2].X, truncdecimalshz, False)]) & \
                                    set(self.lookupy[self.roundandtruncate(lineserials[i1][2].Y, truncdecimalshz, False)]) & \
                                    set(self.lookupz[self.roundandtruncate(lineserials[i1][2].Z, truncdecimalsvz, False)])

                            set4 =  set(self.lookupx[self.roundandtruncate(lineserials[i1][2].X, truncdecimalshz,  True)]) & \
                                    set(self.lookupy[self.roundandtruncate(lineserials[i1][2].Y, truncdecimalshz,  True)]) & \
                                    set(self.lookupz[self.roundandtruncate(lineserials[i1][2].Z, truncdecimalsvz,  True)])

                            # but we need to OR the sets, since we need to cover all variations due to the tolerance check
                            # without the tolerance check it would be simpler and faster
                            closebyindex = set1 | set2 | set3 | set4

                        except:
                            closebyindex = []

                        # the additional if-instruction might be slightly faster
                        # it probably saves most of the time the 'for' and 'if-or' instruction
                        # when closebyindex only contains the index i1 itself
                        if closebyindex.Count > 1: 
                            for i2 in closebyindex:

                                # we don't want to check/delete the current line itself
                                # or do checks before i1
                                # or do all the checks if the line has been marked already
                                if i2 <= i1 or lineserials[i2][3] == True:
                                    continue

                                # test in original orientation
                                deltabeginorg = Vector3D(lineserials[i1][1], lineserials[i2][1])
                                deltaendorg = Vector3D(lineserials[i1][2], lineserials[i2][2])
                                # test in flipped orientation
                                deltabeginflipped = Vector3D(Vector3D(lineserials[i1][1], lineserials[i2][2]))
                                deltaendflipped = Vector3D(lineserials[i1][2], lineserials[i2][1])

                                if (round(deltabeginorg.Length2D, 10) <= self.hztol.Distance and round(deltaendorg.Length2D, 10) <= self.hztol.Distance) or \
                                   (round(deltabeginflipped.Length2D, 10) <= self.hztol.Distance and round(deltaendflipped.Length2D, 10) <= self.hztol.Distance):
                                    
                                    if (abs(round(deltabeginorg.Z, 10)) <= self.vztol.Distance and abs(round(deltaendorg.Z, 10)) <= self.vztol.Distance) or \
                                       (abs(round(deltabeginflipped.Z, 10)) <= self.vztol.Distance and abs(round(deltaendflipped.Z, 10)) <= self.vztol.Distance):

                                        lineserials[i2][3] = True # tag for deleting

                    ProgressBar.TBC_ProgressBar.Title = "deleting duplicates"
                    
                    GlobalSelection.Clear() # need to clear here - otherwise it's too slow
                    deletecount = 0
                    time1 = datetime.now()
                    for i in range(0, lineserials.Count):
                        #if (i * 100 // lineserials.Count) % 2 == 0:
                        if (datetime.now() - time1).seconds > 1:
                            if ProgressBar.TBC_ProgressBar.SetProgress(i * 100 // lineserials.Count):
                                break
                            time1 = datetime.now()

                        if lineserials[i][3] == True:
                            
                            o = self.currentProject.Concordance[lineserials[i][0]]
                            o.GetSite().Remove(o.SerialNumber)
                            deletecount += 1

                    ProgressBar.TBC_ProgressBar.Title = "reinstating selection"
                    # reinstate selection
                    finalselection = []
                    for i in range(0, lineserials.Count):
                        if lineserials[i][3] == False: # not deleted
                            finalselection.Add(lineserials[i][0])
                    GlobalSelection.Items(self.currentProject).Set(finalselection)

                    self.success.Content += '\ndeleted ' + str(deletecount) + ' lines'

                elif self.highlightmode.IsChecked:
                
                    lineserials = []

                    for o in self.objs:
                        if isinstance(o, self.lType):                

                            lineserials.Add(o.SerialNumber)

                    lineserials.sort()
                    
                    for i1 in range(0, lineserials.Count - 1):

                        if not i1 == lineserials.Count - 1:

                            l1 = self.currentProject.Concordance[lineserials[i1]] # get the point object via its serial number        
                        
                            polyseg1 = l1.ComputePolySeg()
                            polyseg1 = polyseg1.ToWorld()
                            polyseg1_v = l1.ComputeVerticalPolySeg()

                            s1 = polyseg1.FirstSegment

                            while s1 is not None:

                                s1_B = s1.BeginPoint
                                s1_E = s1.EndPoint
                                if polyseg1_v != None:
                                    s1_B.Z = polyseg1_v.ComputeVerticalSlopeAndGrade(s1.BeginStation)[1]
                                    s1_E.Z = polyseg1_v.ComputeVerticalSlopeAndGrade(s1.EndStation)[1]

                                for i2 in range(i1 + 1, lineserials.Count):

                                    l2 = self.currentProject.Concordance[lineserials[i2]] # get the point object via its serial number        

                                    polyseg2 = l2.ComputePolySeg()
                                    polyseg2 = polyseg2.ToWorld()
                                    polyseg2_v = l2.ComputeVerticalPolySeg()

                                    s2 = polyseg2.FirstSegment

                                    while s2 is not None:

                                        if s1.Type == s2.Type:
                                            
                                            s2_B = s2.BeginPoint
                                            s2_E = s2.EndPoint
                                            if polyseg2_v != None:
                                                s2_B.Z = polyseg2_v.ComputeVerticalSlopeAndGrade(s2.BeginStation)[1]
                                                s2_E.Z = polyseg2_v.ComputeVerticalSlopeAndGrade(s2.EndStation)[1]

                                            # test in original orientation
                                            deltabeginorg = Vector3D(s1_B, s2_B)
                                            deltaendorg = Vector3D(s1_E, s2_E)
                                            # test in flipped orientation
                                            deltabeginflipped = Vector3D(s1_B, s2_E)
                                            deltaendflipped = Vector3D(s1_E, s2_B)

                                            dup2d = False
                                            dup3d = False
                                            if (round(deltabeginorg.Length2D, 10) <= self.hztol.Distance and round(deltaendorg.Length2D, 10) <= self.hztol.Distance) or \
                                               (round(deltabeginflipped.Length2D, 10) <= self.hztol.Distance and round(deltaendflipped.Length2D, 10) <= self.hztol.Distance):
                                                dup2d = True
                                            
                                            if (abs(round(deltabeginorg.Z, 10)) <= self.vztol.Distance and abs(round(deltaendorg.Z, 10)) <= self.vztol.Distance) or \
                                               (abs(round(deltabeginflipped.Z, 10)) <= self.vztol.Distance and abs(round(deltaendflipped.Z, 10)) <= self.vztol.Distance):
                                                dup3d = True
                                                dup2d = False

                                            if dup3d:
                                                newcircle = wv.Add(clr.GetClrType(CadCircle))
                                                newcircle.Layer = self.layerpicker.SelectedSerialNumber
                                                tt = s1.ComputePoint(0.5)[1]
                                                tt.Z = (s1_B.Z + s1_E.Z)/2
                                                newcircle.CenterPoint = tt
                                                newcircle.Radius = 5
                                                newcircle.Color = Color.Red

                                                self.error3Dduplicate.Content = '3D duplicate'

                                            elif dup2d:
                                                newcircle = wv.Add(clr.GetClrType(CadCircle))
                                                newcircle.Layer = self.layerpicker.SelectedSerialNumber
                                                tt = s1.ComputePoint(0.5)[1]
                                                tt.Z = (s1_B.Z + s1_E.Z)/2
                                                newcircle.CenterPoint = tt
                                                newcircle.Radius = 5
                                                newcircle.Color = Color.Orange

                                                self.error2Dduplicate.Content = '2D duplicate'

                                            t1 = s1


                                        s2 = polyseg2.Next(s2)


                                s1 = polyseg1.Next(s1)

                failGuard.Commit()
                UIEvents.RaiseAfterDataProcessing(self, UIEventArgs())
                self.currentProject.TransactionManager.AddEndMark(CommandGranularity.Command)
        
        except Exception as e:
            tt = sys.exc_info()
            exc_type, exc_obj, exc_tb = sys.exc_info()
            # EndMark MUST be set no matter what
            # otherwise TBC won't work anymore and needs to be restarted
            self.currentProject.TransactionManager.AddEndMark(CommandGranularity.Command)
            UIEvents.RaiseAfterDataProcessing(self, UIEventArgs())
            self.error.Content += '\nan Error occurred - Result probably incomplete\n' + str(exc_type) + '\n' + str(exc_obj) + '\nLine ' + str(exc_tb.tb_lineno)

        self.SaveOptions()           
        Keyboard.Focus(self.okBtn)        
        ProgressBar.TBC_ProgressBar.Title = ""
        
        wv.PauseGraphicsCache(False)
    
    def truncate(self, number, decimals=0):
        """
        Returns a value truncated to a specific number of decimal places.
        """
        if not isinstance(decimals, int):
            raise TypeError("decimal places must be an integer.")
        elif decimals < 0:
            raise ValueError("decimal places has to be 0 or more.")
        elif decimals == 0:
            return math.trunc(number)
        
        factor = 10.0 ** decimals
        return math.trunc(number * factor) / factor

    def roundandtruncate(self, number, decimals=0, up=False):
        """
        Returns a value truncated to a specific number of decimal places.
        """
        if not isinstance(decimals, int):
            raise TypeError("decimal places must be an integer.")
        elif decimals < 0:
            raise ValueError("decimal places has to be 0 or more.")
        elif decimals == 0:
            return math.trunc(number)
        
        factor = 10.0 ** decimals
        if up:
            #t0 = number * factor
            #t1 = math.ceil(number * factor)
            #t2 = math.trunc(math.ceil(number * factor))
            t3 = math.trunc(math.ceil(number * factor)) / factor
            return math.trunc(math.ceil(number * factor)) / factor
        else:
            #t0 = number * factor
            #t1 = math.floor(number * factor)
            #t2 = math.trunc(math.floor(number * factor))
            t3 = math.trunc(math.floor(number * factor)) / factor
            return math.trunc(math.floor(number * factor)) / factor
