import clr
import sys
import csv
import copy
import math
import System
import json
import time
import shutil
import webbrowser
import re
from threading import Thread, Lock
from multiprocessing import cpu_count, Process
import random
import os
import subprocess

from timeit import default_timer as timer
from datetime import timedelta, datetime
from io import StringIO
#from collections import OrderedDict

clr.AddReference ('IronPython.Wpf')
import wpf

from System import Math, Action, Func, String, Guid, Byte, UInt16, UInt32, Int32, Environment
from System import Type, Tuple, Array, Double
from System.Collections.ObjectModel import ObservableCollection
clr.AddReference ("System.Drawing")
from System.Drawing import Bitmap, Color
clr.AddReference ("System.Data")
from System.Data import DataTable, DataColumn, DataRow
from System.IO import StreamReader, MemoryStream, File
from System.Text import Encoding
from System.Windows import Window, Visibility, MessageBox, MessageBoxResult, MessageBoxButton
from System.Windows.Controls import StackPanel, ComboBox, ComboBoxItem, ListView, ListBox, ListBoxItem, ListViewItem, ItemCollection, TreeView, TreeViewItem, Grid, DataGridTextColumn, GridViewColumn, ColumnDefinition, RowDefinition, TextBlock, TextBox, ComboBox
from System.Windows.Data import Binding
clr.AddReference ("System.Windows.Forms")
from System.Windows.Forms import Clipboard, Control, Keys, OpenFileDialog, DialogResult, FolderBrowserDialog, ColumnHeader, BindingSource
clr.AddReference("WindowsFormsIntegration")
from System.Windows.Forms.Integration import ElementHost
from System.Windows.Input import Keyboard, AccessKeyManager
from System.Windows.Shapes import Rectangle
from System.Windows.Threading import Dispatcher
#import InfragisticsDlls
#from InfragisticsDlls import Workbook, Worksheet, WindowOptions, XamSpreadsheet

# we are referencing way too many Trimble functions
# but that way it is easier to fix in case they move stuff around again
try:
    clr.AddReference ("Trimble.Sdk") # In version 5.50, model assemblies are "pre-referenced"
    clr.AddReference ("Trimble.Sdk.CompositeEntities") 
    clr.AddReference ("Trimble.Sdk.Primitives") # contains Trimble.Vce.Collections
    clr.AddReference ("Trimble.Sdk.Features")
    clr.AddReference ("Trimble.Sdk.GraphicsModel") # Trimble.Vce.TTMetrics
    clr.AddReference ("Trimble.Sdk.Properties") # Trimble Properties
    clr.AddReference ("Trimble.Sdk.SurveyCad") # Trimble.Vce.SurveyCAD
    
except:
    clr.AddReference ("Trimble.DiskIO")
    clr.AddReference ("Trimble.Vce.Alignment")
    clr.AddReference ("Trimble.Vce.Collections")
    clr.AddReference ("Trimble.Vce.Coordinates")
    clr.AddReference ("Trimble.Vce.Core")
    clr.AddReference ("Trimble.Vce.Data")
    clr.AddReference ("Trimble.Vce.Data.COGO")
    clr.AddReference ("Trimble.Vce.Data.Construction")
    clr.AddReference ("Trimble.Vce.Data.Scanning")
    clr.AddReference ("Trimble.Vce.Data.RawData")
    clr.AddReference ("Trimble.Vce.Features")
    clr.AddReference ("Trimble.Vce.ForeignCad")
    clr.AddReference ("Trimble.Vce.Gem")
    clr.AddReference ("Trimble.Vce.Geometry")
    clr.AddReference ("Trimble.Vce.Graphics")
    clr.AddReference ("Trimble.Vce.Interfaces")
    clr.AddReference ("Trimble.Vce.TTMetrics")
    clr.AddReference ("Trimble.Vce.Units")

from Trimble.DiskIO import OptionsManager

try: # new in 2024.00
    clr.AddReference ("Trimble.Rw.Core")
    from Trimble.Rw.Core.VectorMath.Geometry import Plane3D as RwPlane3D
    from Trimble.Rw.Core.VectorMath import Point3D as RwPoint3D
except:
    pass

from Trimble.Vce.Alignment import ProfileView, VerticalAlignment, Linestring, AlignmentLabel, DrapedLine, DynaView, SurfaceTie, Sideslope

from Trimble.Vce.Alignment.Linestring import Linestring, ElementFactory, IXYZLocation, IPointIdLocation

from Trimble.Vce.Alignment.Linestring import IStraightSegment, ISmoothCurveSegment, IBestFitArcSegment, IArcSegment, IPIArcSegment, ITangentArcSegment

from Trimble.Vce.Collections import Point3DArray, DynArray

from Trimble.Vce.Coordinates import Point as CoordPoint, ICoordinate, PointCollection, OfficeEnteredCoord, KeyedIn, CoordComponentType, CoordQuality, CoordSystem, CoordType, CoordinateSystemDefinition as CSD

from Trimble.Vce.Core import TransactMethodCall, ModelEvents, EntityEventArgs, CalculateProjectEvents

from Trimble.Vce.Core.Components import WorldView, Project, Layer, LayerGroupCollection, LayerCollection, TextStyle, TextStyleCollection, LineStyleCollection, BlockView, EntityContainerBase, PointLabelStyle, SnapInAttributeExtension, ViewFilter, UserDefinedAttributes

from Trimble.Vce.Corridor import Template as CorridorTemplate

from Trimble.Vce.Data import PointCloudSelection, FileProperties, FilePropertiesContainer, MediaFolder, MediaFolderContainer, Shell3D

from Trimble.Vce.Data.COGO import Calc

from Trimble.Vce.Data.Construction.IFC import BIMEntityCollection, BIMEntity, IFCMesh # Shell3D

from Trimble.Vce.Data.Construction.Materials import MiscMaterial

from Trimble.Vce.Data.Construction.Settings import ConstructionCommandsSettings

from Trimble.Vce.Data.RawData import PointManager, RawDataContainer, RawDataBlock, GeoReferencedImage, GeoReferencedImage3D

clr.AddReference ("Trimble.Vce.Data.RXL")
from Trimble.Vce.Data.RXL import RXLAlignmentExporter, FileWriter as RxlFileWriter, Versions as RxlVersions

clr.AddReference ("Trimble.Vce.Data.GeoRefImage")
from Trimble.Vce.Data.GeoRefImage import WorldFileFormat, TiePoint

clr.AddReference ("Trimble.Vce.Data.IFC")  
from Trimble.VCE.Data.IFC import IfcExporter

clr.AddReference ("Trimble.Vce.Data.RXL")
from Trimble.Vce.Data.RXL import RXLAlignmentExporter, FileWriter as RxlFileWriter, Versions as RxlVersions

from Trimble.Vce.Data.Scanning import PointCloudRegion, ExposedPointCloudRegion

from Trimble.Vce.Features import FeatureManager, LineFeature

from Trimble.Vce.ForeignCad import PolyLine, PolyLineBase, Poly3D, Arc as ArcObject, Circle as CadCircle, Face3D # we are also using Arc from geometry

from Trimble.Vce.ForeignCad import Point as CadPoint, MText, Text as CadText, BlockReference, Leader, LeaderType, DimArrowheadType, PointLabelEntity as CadLabel, AttachmentPoint, TextUtilities, Hatch

from Trimble.Vce.Gem import VextexAndTriangleList, Model3D, ProjectedSurface, SlopingLevelSurface, ElevationSlopeTypes, Gem, Filer, DtmVolumes, Model3DQuickContours, Model3DContoursBuilder, ModelBoundaries, GemVertexType, Model3DCompSettings, DisplayMode, SiteImprovementMaterialCollection, ConstructionMaterialCollection, GemMaterials, GemMaterialMap, SurfaceClassification

from Trimble.Vce.Geometry import Triangle2D, Triangle3D, Point3D, Plane3D, Arc, Matrix4D, Vector2D, Vector3D, BiVector3D, Spinor3D, PolySeg, Limits3D, Side, Intersections, RectangleD, Primitive, PrimitiveLocation, Conversions, Line3D, Parabola

from Trimble.Vce.Geometry.PolySeg.Segment import Segment, Line as SegmentLine, Arc as ArcSegment, Parabola as ParabolaSegment
try:
    #2023.10
    from Trimble.Vce.Geometry import FergusonSpline
except:
    #5.90
    from Trimble.Vce.Geometry.PolySeg.Segment import FergusonSpline


from Trimble.Vce.Geometry.Region import Region, RegionBuilder

from Trimble.Vce.Graphics import LeftMouseModeType, GraphicMarkerTypes

clr.AddReference("Trimble.Vce.GraphicsEngine2D")
from Trimble.Vce.GraphicsEngine import OverlayBag

from Trimble.Vce.Interfaces import Client, ProgressBar, Point as PointHelper
try: # new in 2024.00
    from Trimble.Vce.Interfaces import TriangulationContext, TransformationContext
except:
    pass

from Trimble.Vce.Interfaces.Client import CommandGranularity

from Trimble.Vce.Interfaces.Core import OverrideByLayer

try:
	#5.70
	from Trimble.Vce.Interfaces.Construction import UtilityNodeType
except:
    #5.60.2
    from Trimble.Vce.Utility import UtilityNodeType

from Trimble.Vce.Interfaces.SnapIn import IPolyseg, IName, IHaveUcs, ISnapIn, IPointCloudReader, IMemberManagement, ICollectionOfEntities, TransformData, DTMSharpness, SurfaceRebuildMethod, SnapMode

from Trimble.Vce.Interfaces.PointCloud import IExposedPointCloudRegion
#from Trimble.Vce.Interfaces.PointCloudIntegration import LightWeightScanPointBatch

from Trimble.Vce.Interfaces.Units import ILinear, LinearType, CoordinateType

from Trimble.Vce.PlanSet import PlanSetSheetViews, PlanSetSheetView, SheetSet, BasicSheet, XSSheetSet, ProfileSheetSet

from Trimble.Properties import PropertyKeys

from Trimble.Vce.SurveyCAD import ProjectLineStyle, TextDisplayAttr

from Trimble.Vce.TTMetrics import StrokeFont, StrokeFontManager

from Trimble.Vce.Utility import UtilityNode, UtilityNetwork

clr.AddReference ("Trimble.Vce.UI.BaseCommands")
from Trimble.Vce.UI.BaseCommands import ViewHelper, SelectionContextMenuHandler, ExploreObjectControlHelper

clr.AddReference ("Trimble.Vce.UI.ConstructionCommands")
from Trimble.Vce.UI.ConstructionCommands import LimitSliceWindow

clr.AddReference ("Trimble.Vce.UI.Controls")
from Trimble.Vce.UI.Controls import SurfaceTypeLists, TrimbleColor, ExplorerUI, ExplorerItemCollection, DisplayWindow, StationEdit, Wpf as TBCWpf, VceMessageBox, InputSettings

# GlobalSelection moved to Trimble.Vce.Core in TBC 5.90
try:
    from Trimble.Vce.Core import GlobalSelection
except:
    from Trimble.Vce.UI.Controls import GlobalSelection
    
clr.AddReference("Trimble.Vce.UI.Hoops")
from Trimble.Vce.UI.Hoops import Hoops2dView, Hoops3dView, HoopsSheetView

try:
    clr.AddReference("Trimble.Vce.UI.ScanningCommands")
    from Trimble.Vce.UI.ScanningCommands import CreateBestFitLine
except:
    # moved to Trimble.Vce.Alignment.Linestring in TBC 5.90
    from Trimble.Vce.Alignment.Linestring import CreateBestFitLine

clr.AddReference("Trimble.Vce.UI.UIManager")
from Trimble.Vce.UI.UIManager import UIEvents, TrimbleOffice

try: #5.90
    clr.AddReference("Trimble.Vce.ViewModel")
    from Trimble.Vce.ViewModel.CommandLine.CommandLineCommands import CommandHelper
except: #2023.10
    clr.AddReference("Trimble.Sdk.UI.Commands")
    from Trimble.Sdk.UI.Commands.CommandLine import CommandHelper

from Trimble.Sdk.CompositeEntities.Interfaces import ICompositeGeometry

# later version of TBC moved these to a different assembly. If not found in new location, look at old
try:
    #2023.10
    #clr.AddReference("Trimble.Sdk.UI")
    from Trimble.Sdk.UI import MousePosition, InputMethod, CursorStyle, UIEventArgs, I2DProjection, DistanceType
    from Trimble.Sdk.Interfaces.UI import ControlBoolean
except:
    try:
    	#5.50
        from Trimble.Sdk.Interfaces.UI import InputMethod, MousePosition, CursorStyle, ControlBoolean, UIEventArgs, I2DProjection, DistanceType
    except:
        try:
    		#5.40 or so
            from Trimble.Vce.UI.UIManager import UIEventArgs
            from Trimble.CustomControl.Interfaces import MousePosition, ControlBoolean, I2DProjection
            from Trimble.CustomControl.Interfaces.Enums import CursorStyle, InputMethod
        except:
    		# even older
            from Trimble.Vce.UI.Controls import MousePosition, CursorStyle, ControlBoolean, TrimbleColor

def Setup(cmdData, macroFileFolder):
    cmdData.Key = "SCR_ElevateSHPLines"
    cmdData.CommandName = "SCR_ElevateSHPLines"
    cmdData.Caption = "_SCR_ElevateSHPLines"
    cmdData.UIForm = "SCR_ElevateSHPLines"      # MUST MATCH NAME FROM CLASS DEFINED BELOW !!!
    cmdData.HelpFile = "Macros.chm"
    cmdData.HelpTopic = "22602"

    try:
        cmdData.DefaultTabKey = "SCR Expld-SNR-Relay-Prop"
        cmdData.DefaultTabGroupKey = "Properties"
        cmdData.ShortCaption = "elevate SHP-Lines"
        cmdData.DefaultRibbonToolSize = 3 # Default=0, ImageOnly=1, Normal=2, Large=3

        cmdData.Version = 1.00
        cmdData.MacroAuthor = "SCR"
        cmdData.MacroInfo = r""
        
        cmdData.ToolTipTitle = "elevate lines based on their feature attribute"
        cmdData.ToolTipTextFormatted = "elevate lines based on their feature attribute"

    except:
        pass
    try:
        b = Bitmap (macroFileFolder + "\\" + cmdData.Key + ".png") # we have to include a icon revision, otherwise TBC might not show the new one
        cmdData.ImageSmall = b
    except:
        pass


class SCR_ElevateSHPLines(StackPanel): # this inherits from the WPF StackPanel control
    def __init__(self, currentProject, macroFileFolder):
        with StreamReader (macroFileFolder + r"\SCR_ElevateSHPLines.xaml") as s:
            wpf.LoadComponent (self, s)
        self.currentProject = currentProject


    def OnLoad(self, cmd, buttons, event):
        self.okBtn = buttons[0]
        self.Caption = cmd.Command.Caption

        optionMenu = SelectionContextMenuHandler()
        # remove options that don't apply here
        optionMenu.ExcludedCommands = "SelectObservations | SelectPoints | SelectDuplicatePoints"
        self.objs.ButtonContextMenu = optionMenu
        self.objs.IsEntityValidCallback = self.IsValid

        self.lType = clr.GetClrType(IPolyseg)
        #self.compType = clr.GetClrType(IPolyseg)

        # get the units for linear distance
        self.lunits = self.currentProject.Units.Linear

        #self.lfp = self.lunits.Properties.Copy()
        self.linearsuffix = self.lunits.Units[self.lunits.DisplayType].Abbreviation

        self.SetDefaultOptions()

    def SetDefaultOptions(self):
        self.featureattr.Text = OptionsManager.GetString("SCR_ElevateSHPLines.featureattr", "Elevation")

        lserial = OptionsManager.GetUint("SCR_ElevateSHPLines.layerpicker", 8)
        o = self.currentProject.Concordance.Lookup(lserial) # get the object withj the saved serial number
        if o != None:   # check if we actually got an object back
            if isinstance(o.GetSite(), LayerCollection):    # check if the object is a layer
                self.layerpicker.SetSelectedSerialNumber(lserial, InputMethod(3))
            else:  # if not then set Layer zero                       
                self.layerpicker.SetSelectedSerialNumber(8, InputMethod(3))
        else:   # if not then set Layer zero               
            self.layerpicker.SetSelectedSerialNumber(8, InputMethod(3))

    def SaveOptions(self):
        OptionsManager.SetValue("SCR_ElevateSHPLines.featureattr", self.featureattr.Text)
        OptionsManager.SetValue("SCR_ElevateSHPLines.layerpicker", self.layerpicker.SelectedSerialNumber)

    def IsValid(self, serial):
        o = self.currentProject.Concordance.Lookup(serial)
        if isinstance(o, self.lType):
            return True
        return False

    def OkClicked(self, cmd, e):
        
        self.success.Content = ""
        self.error.Content = ""


        self.currentProject.TransactionManager.AddBeginMark(CommandGranularity.Command, self.Caption)
        UIEvents.RaiseBeforeDataProcessing(self, UIEventArgs())


        try:
            # the "with" statement will unroll any changes if something go wrong
            with TransactMethodCall(self.currentProject.TransactionCollector) as failGuard:


                for o in self.currentProject:
                #find FeatureManager as object
                    if isinstance(o, FeatureManager):
                        fm = o

                for o in self.objs:
                    
                    if isinstance(o, ICompositeGeometry):
                        foundelev = False

                        # need to jump throughs hoops since the featurecode is protected in composite geometry
                        # need to do it in reverse, go through all featurecodes and look if it's referring to the current object
                        for f in fm:
                            for e in self.currentProject.Concordance.GetObserversOf(f.SerialNumber):

                                if e == o:
                            
                                    fc = f
                                    break
                        if fc:
                            for attr in fc.Attributes:
                                if attr.Name == self.featureattr.Text:
                                    elev = self.lunits.Convert(self.lunits.DisplayType, float(attr.Value), self.lunits.InternalType)
                                    foundelev = True
                                    break

                            if foundelev:

                                for e in o:
                                    if isinstance(e.SnapIn, self.lType):
                                        self.drawline(e.SnapIn, elev)

                            else:
                                o.Color = Color.Red

                        
                    elif isinstance(o, self.lType):

                        foundelev = False
                        # get the line feature code
                        for observes in self.currentProject.Concordance.GetIsObservedBy(o.SerialNumber):
                            if observes and isinstance(observes, LineFeature):
                                for attr in observes.Attributes:
                                    if attr.Name == self.featureattr.Text:
                                        elev = self.lunits.Convert(self.lunits.DisplayType, float(attr.Value), self.lunits.InternalType)
                                        foundelev = True
                                        break

                        if foundelev:

                            self.drawline(o, elev)

                        else:
                            o.Color = Color.Red

                failGuard.Commit()
                UIEvents.RaiseAfterDataProcessing(self, UIEventArgs())
                self.currentProject.TransactionManager.AddEndMark(CommandGranularity.Command)
        
        except Exception as e:
            tt = sys.exc_info()
            exc_type, exc_obj, exc_tb = sys.exc_info()
            # EndMark MUST be set no matter what
            # otherwise TBC won't work anymore and needs to be restarted
            self.currentProject.TransactionManager.AddEndMark(CommandGranularity.Command)
            UIEvents.RaiseAfterDataProcessing(self, UIEventArgs())
            self.error.Content += '\nan Error occurred - Result probably incomplete\n' + str(exc_type) + '\n' + str(exc_obj) + '\nLine ' + str(exc_tb.tb_lineno)


                    #self.success.Content += '\n' + o.GetType().Name + ' - SN#: ' + str(o.SerialNumber)
                    #tt = o.GetSite()
                    #tt2 = o

        self.SaveOptions()

    def drawline(self, l, elev):

        wv = self.currentProject [Project.FixedSerial.WorldView]

        polyseg = l.ComputePolySeg()
        polyseg = polyseg.ToWorld()
        polyseg_v = PolySeg.PolySeg()
        polyseg_v.Add(Point3D(0, elev, 0))
        
        ls = wv.Add(clr.GetClrType(Linestring))
        ls.Append(polyseg, polyseg_v, False, False)
        ls.Layer = self.layerpicker.SelectedSerialNumber

        return

