#   GNU GPLv3
#   <this is an add-on Script/Macro for the geospatial software "Trimble Business Center" aka TBC>
#   <you'll need at least the "Survey Advanced" licence of TBC in order to run this script>
#	<see the ToolTip section below for a brief explanation what the script does>
#	<see the Help-Files for more details>
#   Copyright (C) 2023 Ronny Schneider
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <https://www.gnu.org/licenses/>

from System.Collections.Generic import List, IEnumerable # import here, otherwise there is a weird issue with Count and Add for lists
import os
execfile("C:\ProgramData\Trimble\MacroCommands\SCR Macros\SCR_Imports.py")

def Setup(cmdData, macroFileFolder):
    cmdData.Key = "SCR_ExplodeIFC"
    cmdData.CommandName = "SCR_ExplodeIFC"
    cmdData.Caption = "_SCR_ExplodeIFC"
    cmdData.UIForm = "SCR_ExplodeIFC" # MUST MATCH NAME FROM CLASS DEFINED BELOW !!!

    try:
        cmdData.DefaultTabKey = "SCR Expld-SNR-Relay-Prop"
        cmdData.DefaultTabGroupKey = "Explode"
        cmdData.ShortCaption = "Explode IFC"
        cmdData.DefaultRibbonToolSize = 3 # Default=0, ImageOnly=1, Normal=2, Large=3
     
        cmdData.Version = 1.05
        cmdData.MacroAuthor = "SCR"
        cmdData.ToolTipTitle = "explode IFC"
        cmdData.ToolTipTextFormatted = "explode IFC solid objects with angle filter"
    except:
        pass
    try:
        b = Bitmap(macroFileFolder + "\\" + cmdData.Key + ".png")
        cmdData.ImageSmall = b
    except:
        pass

# the name of this class must match name from cmdData.UIForm (above)
class SCR_ExplodeIFC(StackPanel): # this inherits from the WPF StackPanel control
    def __init__(self, currentProject, macroFileFolder):
        with StreamReader(macroFileFolder + r"\SCR_ExplodeIFC.xaml") as s:
            wpf.LoadComponent(self, s)
        self.currentProject = currentProject
        self.macroFileFolder = macroFileFolder

    def HelpClicked(self, cmd, e):
        webbrowser.open("C:\ProgramData\Trimble\MacroCommands\SCR Macros\MacroHelp\MacroHelp.htm#_" + type(self).__name__)

    def OnLoad(self, cmd, buttons, event):
        self.okBtn = buttons[0]
        buttons[2].Content = "Help"
        buttons[2].Visibility = Visibility.Visible
        buttons[2].Click += self.HelpClicked
        self.Caption = cmd.Command.Caption
        
        self.ifcType = clr.GetClrType(IFCMesh)

        self.ifcs.IsEntityValidCallback = self.IsValidIFC

        # populate combobox
        # item = ComboBoxItem()
        # item.Content = "Up"
        # item.FontSize = 12
        # self.facedirection.Items.Add(item)
        # item = ComboBoxItem()
        # item.Content = "Down"
        # item.FontSize = 12
        # self.facedirection.Items.Add(item)
        # item = ComboBoxItem()
        # item.Content = "Vertical"
        # item.FontSize = 12
        # self.facedirection.Items.Add(item)



		# after changing the input fields in a lot of macros from the old textboxes to floating point number or distance edits
		# it could happen that old settings, saved as strings, would throw a type cast error
		# hence it's better to have it in a try block
        try:
            self.SetDefaultOptions()
        except:
            pass
    

    def IsValidIFC(self, serial):
        o = self.currentProject.Concordance.Lookup(serial)
        if isinstance(o, self.ifcType):
            return True
        return False
        
    
    def SetDefaultOptions(self):

        self.maindirection.Angle = OptionsManager.GetDouble("SCR_ExplodeIFC.maindirection", 0.000)
        self.anglevariation.Angle = OptionsManager.GetDouble("SCR_ExplodeIFC.anglevariation", 0.000)

        try:    self.outcolorpicker.SelectedColor = Color.FromArgb(OptionsManager.GetInt("SCR_ExplodeIFC.outcolorpicker"))
        except: self.outcolorpicker.SelectedColor = TrimbleColor.ByLayer
        
        self.addtolayername.Text = OptionsManager.GetString("SCR_ExplodeIFC.addtolayername", " - Lines")

    def SaveOptions(self):

        OptionsManager.SetValue("SCR_ExplodeIFC.maindirection", self.maindirection.Angle)
        OptionsManager.SetValue("SCR_ExplodeIFC.anglevariation", self.anglevariation.Angle)
        OptionsManager.SetValue("SCR_ExplodeIFC.outcolorpicker", self.outcolorpicker.SelectedColor.ToArgb())
        OptionsManager.SetValue("SCR_ExplodeIFC.addtolayername", self.addtolayername.Text)

    def CancelClicked(self, thisCmd, args):
        thisCmd.CloseUICommand()

    def OkClicked(self, thisCmd, e):

        wv = self.currentProject[Project.FixedSerial.WorldView]


        inputok=True
        try:
            #anglevariation = abs(math.radians(self.anglevariation.Value))
            anglevariation = abs(self.anglevariation.Angle)
            self.anglevariation.Angle = anglevariation
        except:
            inputok = False

        if inputok:
            self.currentProject.TransactionManager.AddBeginMark(CommandGranularity.Command, self.Caption)
            UIEvents.RaiseBeforeDataProcessing(self, UIEventArgs())
            try:
                with TransactMethodCall(self.currentProject.TransactionCollector) as failGuard:
                    # we use IFCs
                    # ifclayer  = self.currentProject.Concordance.Lookup(self.ifclayerpicker.SelectedSerialNumber)    # we get just the ifc layer as an object
                    # ifcmembers = ifclayer.Members  # we get serial number list of all the elements on that layer
                    ifccount = 0
                    for o in self.ifcs.SelectedMembers(self.currentProject):
                        if isinstance(o, IFCMesh): # in case it is an IFC Mesh we get us the coordinates
                            ifccount += 1   

                    j = 0
                    for o in self.ifcs.SelectedMembers(self.currentProject):
                        # o = self.currentProject.Concordance.Lookup(sn)
                        
                        if isinstance(o, IFCMesh): # in case it is an IFC Mesh we get us the coordinates

                            inputlayer = self.currentProject.Concordance.Lookup(o.Layer)
                            outputlayer = Layer.FindOrCreateLayer(self.currentProject, inputlayer.Name + self.addtolayername.Text)
                            outputlayer.LayerGroupSerial = inputlayer.LayerGroupSerial

                            linepoints = Array[Point3D]([Point3D()]*2)
                            linetuples = DynArray()

                            # create Point3D List of vertices, not in any order yet
                            verticesP3D = []
                            transform = o.Transformation
                            vertices = o.GetVertex()
                            for v in vertices:
                                verticesP3D.Add(transform.TransformPoint(v))

                            # the function comes from abstract class Trimble.Vce.Data.Shell3D
                            # first we get a list which tells us which vertices are connected
                            vertice_indexes = o.GetTriangulatedFaceList() # the first number seems to be the count of vertices, followed by 3 vertices
                            if vertice_indexes.Count == 0:
                                vertice_indexes = o.GetFaceList() # on some 12d pavement Trimeshes the triangulated function doesn't work

                            for i in range(0, vertice_indexes.Count, 4): # step through all the faces

                                # it can be that the IFC contains "triangles" where all three points are on one line, we don't want those
                                # that would lead to a division by zero in the algorithm that checks if the perpendicular solution is within the triangle
                                # checking it here is doubling up some computations, but it could also mess up the plane and normal vector creation
                                vertice1 = verticesP3D[vertice_indexes[i+1]]
                                vertice2 = verticesP3D[vertice_indexes[i+2]]
                                vertice3 = verticesP3D[vertice_indexes[i+3]]

                                a = Vector3D(vertice1, vertice2)
                                b = Vector3D(vertice1, vertice3)
                                
                                aa = Vector3D.DotProduct(a,a)[0]
                                ab = Vector3D.DotProduct(a,b)[0]
                                bb = Vector3D.DotProduct(b,b)[0]
                                
                                d = round(ab * ab - aa * bb, 14) # otherwise it could still happen that "triangles" slip through

                                # if vertice1.X == vertice2.X and vertice1.X == vertice3.X:
                                #     tt = 0

                                if d != 0:
                                    # find out if we want that triangle
                                    plane = Plane3D(vertice1, vertice2, vertice3)[0]
                                    nv = plane.normal
                                    nv.Length = -0.1 # the normal vectors seem to face to the inside of the solid object, so we turn it around
                                    
                                    # # test show the normal vectors
                                    # l = wv.Add(clr.GetClrType(Linestring))
                                    # e = ElementFactory.Create(clr.GetClrType(IStraightSegment), clr.GetClrType(IXYZLocation))
                                    # e.Position = vertice1 
                                    # l.AppendElement(e)
                                    # e = ElementFactory.Create(clr.GetClrType(IStraightSegment), clr.GetClrType(IXYZLocation))
                                    # e.Position = (vertice1 + nv)
                                    # l.AppendElement(e)
                                    # l.Layer = outputlayer.SerialNumber
                                    # l.Color = Color.Blue

                                    # Vector3D.Horizon is positive above the horizon and negative below
                                    # VerticalAngleEdit starts with 0 in Zenith 
                                    maindirection = (-1 * (self.maindirection.Angle - math.pi/2)) + math.pi/2
                                    
                                    if (maindirection - anglevariation) <= nv.Horizon and \
                                       (maindirection + anglevariation) >= nv.Horizon:
                                        #combox.selecteditem.content
                                        linepoints[0] = vertice1
                                        linepoints[1] = vertice2

                                        #check if it exists in the tuple list already, one way or the other
                                        foundduplicate = False
                                        for testtuple in linetuples:
                                            if Point3D.IsDuplicate(linepoints[0], testtuple[0]) and \
                                               Point3D.IsDuplicate(linepoints[1], testtuple[1]):
                                                foundduplicate = True
                                            if Point3D.IsDuplicate(linepoints[1], testtuple[0]) and \
                                               Point3D.IsDuplicate(linepoints[0], testtuple[1]):
                                                foundduplicate = True
                                        if foundduplicate == False:
                                            linetuples.Add(linepoints.Clone())
                                        
                                        linepoints[0] = vertice2
                                        linepoints[1] = vertice3
                                        #check if it exists in the tuple list already, one way or the other
                                        foundduplicate = False
                                        for testtuple in linetuples:
                                            if Point3D.IsDuplicate(linepoints[0], testtuple[0]) and \
                                               Point3D.IsDuplicate(linepoints[1], testtuple[1]):
                                                foundduplicate = True
                                            if Point3D.IsDuplicate(linepoints[1], testtuple[0]) and \
                                               Point3D.IsDuplicate(linepoints[0], testtuple[1]):
                                                foundduplicate = True
                                        if foundduplicate == False:
                                            linetuples.Add(linepoints.Clone())
                                        
                                        linepoints[0] = vertice3
                                        linepoints[1] = vertice1
                                        #check if it exists in the tuple list already, one way or the other
                                        foundduplicate = False
                                        for testtuple in linetuples:
                                            if Point3D.IsDuplicate(linepoints[0], testtuple[0]) and \
                                               Point3D.IsDuplicate(linepoints[1], testtuple[1]):
                                                foundduplicate = True
                                            if Point3D.IsDuplicate(linepoints[1], testtuple[0]) and \
                                               Point3D.IsDuplicate(linepoints[0], testtuple[1]):
                                                foundduplicate = True
                                        if foundduplicate == False:
                                            linetuples.Add(linepoints.Clone())

                            for drawtuple in linetuples:
                                
                                l = wv.Add(clr.GetClrType(Linestring))
                                e = ElementFactory.Create(clr.GetClrType(IStraightSegment), clr.GetClrType(IXYZLocation))
                                e.Position = drawtuple[0] 
                                l.AppendElement(e)
                                e = ElementFactory.Create(clr.GetClrType(IStraightSegment), clr.GetClrType(IXYZLocation))
                                e.Position = drawtuple[1]
                                l.AppendElement(e)
                                l.Layer = outputlayer.SerialNumber
                                l.Color = self.outcolorpicker.SelectedColor

                            j += 1
                            ProgressBar.TBC_ProgressBar.Title = "exploded IFC: " + str(j) + "/" + str(ifccount)
                            if ProgressBar.TBC_ProgressBar.SetProgress(math.floor(j * 100 / ifccount)):
                                break   # function returns true if user pressed cancel
                    
                    failGuard.Commit()
                    UIEvents.RaiseAfterDataProcessing(self, UIEventArgs())
                    self.currentProject.TransactionManager.AddEndMark(CommandGranularity.Command)
        
            except Exception as e:
                tt = sys.exc_info()
                exc_type, exc_obj, exc_tb = sys.exc_info()
                # EndMark MUST be set no matter what
                # otherwise TBC won't work anymore and needs to be restarted
                self.currentProject.TransactionManager.AddEndMark(CommandGranularity.Command)
                UIEvents.RaiseAfterDataProcessing(self, UIEventArgs())
                self.error.Content += '\nan Error occurred - Result probably incomplete\n' + str(exc_type) + '\n' + str(exc_obj) + '\nLine ' + str(exc_tb.tb_lineno)
        
        self.SaveOptions()

                