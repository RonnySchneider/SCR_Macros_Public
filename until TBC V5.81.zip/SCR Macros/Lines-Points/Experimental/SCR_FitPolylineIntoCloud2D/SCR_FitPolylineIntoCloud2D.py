#   GNU GPLv3
#   <this is an add-on Script/Macro for the geospatial software "Trimble Business Center" aka TBC>
#   <you'll need at least the "Survey Advanced" licence of TBC in order to run this script>
#	<see the ToolTip section below for a brief explanation what the script does>
#	<see the Help-Files for more details>
#   Copyright (C) 2023 Ronny Schneider
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <https://www.gnu.org/licenses/>

from System.Collections.Generic import List, IEnumerable # import here, otherwise there is a weird issue with Count and Add for lists
import os
execfile("C:\ProgramData\Trimble\MacroCommands\SCR Macros\SCR_Imports.py")

def Setup(cmdData, macroFileFolder):
    cmdData.Key = "SCR_FitPolylineIntoCloud2D"
    cmdData.CommandName = "SCR_FitPolylineIntoCloud2D"
    cmdData.Caption = "_SCR_FitPolylineIntoCloud2D"
    cmdData.UIForm = "SCR_FitPolylineIntoCloud2D"      # MUST MATCH NAME FROM CLASS DEFINED BELOW !!!
    cmdData.HelpFile = "Macros.chm"
    cmdData.HelpTopic = "22602"

    try:
        cmdData.DefaultTabKey = "SCR Lines/Points"
        cmdData.DefaultTabGroupKey = "Experimental"
        cmdData.ShortCaption = "2D-Fit Polyline between Points"
        cmdData.DefaultRibbonToolSize = 3 # Default=0, ImageOnly=1, Normal=2, Large=3

        cmdData.Version = 1.12
        cmdData.MacroAuthor = "SCR"
        cmdData.MacroInfo = r""
        
        cmdData.ToolTipTitle = "2D-Fit Polyline between Points"
        cmdData.ToolTipTextFormatted = "2D-Fit Polyline between Points"

    except:
        pass
    try:
        b = Bitmap (macroFileFolder + "\\" + cmdData.Key + ".png")
        cmdData.ImageSmall = b
    except:
        pass


class SCR_FitPolylineIntoCloud2D(StackPanel): # this inherits from the WPF StackPanel control
    def __init__(self, currentProject, macroFileFolder):
        with StreamReader (macroFileFolder + r"\SCR_FitPolylineIntoCloud2D.xaml") as s:
            wpf.LoadComponent (self, s)
        self.currentProject = currentProject
        self.macroFileFolder = macroFileFolder

    def HelpClicked(self, cmd, e):
        webbrowser.open("C:\ProgramData\Trimble\MacroCommands\SCR Macros\MacroHelp\MacroHelp.htm#_" + type(self).__name__)


    def OnLoad(self, cmd, buttons, event):
        self.okBtn = buttons[0]
        buttons[2].Content = "Help"
        buttons[2].Visibility = Visibility.Visible
        buttons[2].Click += self.HelpClicked
        self.Caption = cmd.Command.Caption
        #types = Array [Type] ([CadPoint]) + Array [Type] ([Point3D])    # we fill an array with TBC object types, we could combine different types
        self.linepicker1.IsEntityValidCallback = self.linepicker1IsValid
        
        self.lType = clr.GetClrType(IPolyseg)
        
        self.objs.IsEntityValidCallback=self.pointsIsValid
        self.cadpointType = clr.GetClrType(CadPoint)
        self.point3dType = clr.GetClrType(Point3D)
        self.coordpointType = clr.GetClrType(CoordPoint)

        self.dxdyspread.NumberOfDecimals = 4
        self.dxdyspread.MinValue = 0.001
        self.dxdystep.NumberOfDecimals = 4
        self.dxdystep.MinValue = 0.001
        self.dxdydivider.NumberOfDecimals = 2
        self.dxdydivider.MinValue = 1.1
        self.dxdybreak.NumberOfDecimals = 8
        self.dxdybreak.MinValue = 0.00000001
        self.maxrot.NumberOfDecimals = 4
        self.maxrot.MinValue = 0.01
        self.rotstep.NumberOfDecimals = 4
        self.rotstep.MinValue = 0.01
        self.rotdivider.NumberOfDecimals = 2
        self.rotdivider.MinValue = 1.1
        self.rotbreak.NumberOfDecimals = 8
        self.rotbreak.MinValue = 0.00000001

		# after changing the input fields in a lot of macros from the old textboxes to floating point number or distance edits
		# it could happen that old settings, saved as strings, would throw a type cast error
		# hence it's better to have it in a try block
        try:
            self.SetDefaultOptions()
        except:
            pass

    def SetDefaultOptions(self):
        self.dxdyspread.Value = OptionsManager.GetDouble("SCR_FitPolylineIntoCloud2D.dxdyspread", 0.2)
        self.dxdystep.Value = OptionsManager.GetDouble("SCR_FitPolylineIntoCloud2D.dxdystep", 0.01)
        self.dxdydivider.Value = OptionsManager.GetDouble("SCR_FitPolylineIntoCloud2D.dxdydivider", 1.2)
        self.dxdybreak.Value = OptionsManager.GetDouble("SCR_FitPolylineIntoCloud2D.dxdybreak", 0.0001)
        self.maxrot.Value = OptionsManager.GetDouble("SCR_FitPolylineIntoCloud2D.maxrot", 45.0)
        self.rotstep.Value = OptionsManager.GetDouble("SCR_FitPolylineIntoCloud2D.rotstep", 5.0)
        self.rotdivider.Value = OptionsManager.GetDouble("SCR_FitPolylineIntoCloud2D.rotdivider", 2.0)
        self.rotbreak.Value = OptionsManager.GetDouble("SCR_FitPolylineIntoCloud2D.rotbreak", 0.00001)

        settingserial = OptionsManager.GetUint("SCR_FitPolylineIntoCloud2D.layerpicker", 8) # 8 is FixedSerial for Layer Zero
        o = self.currentProject.Concordance.Lookup(settingserial)
        if o != None:
            if isinstance(o.GetSite(), LayerCollection):    
                self.layerpicker.SetSelectedSerialNumber(settingserial, InputMethod(3))
            else:                       
                self.layerpicker.SetSelectedSerialNumber(8, InputMethod(3))
        else:                       
            self.layerpicker.SetSelectedSerialNumber(8, InputMethod(3))


    def SaveOptions(self):
        OptionsManager.SetValue("SCR_FitPolylineIntoCloud2D.dxdyspread", self.dxdyspread.Value)
        OptionsManager.SetValue("SCR_FitPolylineIntoCloud2D.dxdystep", self.dxdystep.Value)
        OptionsManager.SetValue("SCR_FitPolylineIntoCloud2D.dxdydivider", self.dxdydivider.Value)
        OptionsManager.SetValue("SCR_FitPolylineIntoCloud2D.dxdybreak", self.dxdybreak.Value)
        OptionsManager.SetValue("SCR_FitPolylineIntoCloud2D.maxrot", self.maxrot.Value)
        OptionsManager.SetValue("SCR_FitPolylineIntoCloud2D.rotstep", self.rotstep.Value)
        OptionsManager.SetValue("SCR_FitPolylineIntoCloud2D.rotdivider", self.rotdivider.Value)
        OptionsManager.SetValue("SCR_FitPolylineIntoCloud2D.rotbreak", self.rotbreak.Value)
        OptionsManager.SetValue("SCR_FitPolylineIntoCloud2D.layerpicker", self.layerpicker.SelectedSerialNumber)
    
    def linepicker1IsValid(self, serial):
        o = self.currentProject.Concordance.Lookup(serial)
        if isinstance(o, self.lType):
            return True
        return False


    def pointsIsValid(self, serial):
        o=self.currentProject.Concordance.Lookup(serial)
        if isinstance(o, self.cadpointType):
            return True
        if isinstance(o, self.point3dType):
            return True
        if isinstance(o, self.coordpointType):
            return True
        return False


    def CancelClicked(self, cmd, args):
        cmd.CloseUICommand ()


    def OkClicked(self, cmd, e):
        Keyboard.Focus(self.okBtn)
        self.error.Content=''


        self.success.Content = ''

        wv = self.currentProject [Project.FixedSerial.WorldView]
        #wv.PauseGraphicsCache(True)
        ProgressBar.TBC_ProgressBar.Title = self.Caption

        # get the units for linear distance
        self.lunits = self.currentProject.Units.Linear
        # we don't want the units to be included (so we make copy and turn that off). Otherwise get something like "12.50 ft"
        self.lfp = self.lunits.Properties.Copy()
        self.lfp.AddSuffix = False

        inputok = True
        l1 = self.linepicker1.Entity
        if l1==None: 
            self.success.Content += '\nno Line 1 selected'
            inputok=False
        
        if self.objs.Count == 0:
            inputok=False

        if inputok:
            self.currentProject.TransactionManager.AddBeginMark(CommandGranularity.Command, self.Caption)
            UIEvents.RaiseBeforeDataProcessing(self, UIEventArgs())
            try:   
                # the "with" statement will unroll any changes if something goes wrong
                with TransactMethodCall(self.currentProject.TransactionCollector) as failGuard:
                    cloudpoints = Point3DArray()
                    centerofcloud = Point3D()
                    currenttestcenter = Point3D()
                    polyrefpoint = self.coordpick1.Coordinate

                    for o in self.objs.SelectedMembers(self.currentProject):
                        if isinstance(o, self.cadpointType):
                            if o.Point0.X != 0 and o.Point0.Y != 0:
                                cloudpoints.Add(o.Point0)
                                centerofcloud.X += o.Point0.X - cloudpoints[0].X # cloud center of gravity, keep numbers small by subtracting the first point
                                centerofcloud.Y += o.Point0.Y - cloudpoints[0].Y # cloud center of gravity, keep numbers small by subtracting the first point
                                centerofcloud.Z += o.Point0.Z - cloudpoints[0].Z # cloud center of gravity, keep numbers small by subtracting the first point
                        elif isinstance(o, self.coordpointType):
                            if o.Position.X != 0 and o.Position.Y != 0:
                                cloudpoints.Add(o.Position)
                                centerofcloud.X += o.Position.X - cloudpoints[0].X # cloud center of gravity, keep numbers small by subtracting the first point
                                centerofcloud.Y += o.Position.Y - cloudpoints[0].Y # cloud center of gravity, keep numbers small by subtracting the first point
                                centerofcloud.Z += o.Position.Z - cloudpoints[0].Z # cloud center of gravity, keep numbers small by subtracting the first point
                    
                    # compute the final center of gravity and revert back to world coordinates
                    centerofcloud.X = centerofcloud.X / cloudpoints.Count + cloudpoints[0].X
                    centerofcloud.Y = centerofcloud.Y / cloudpoints.Count + cloudpoints[0].Y
                    centerofcloud.Z = centerofcloud.Z / cloudpoints.Count + cloudpoints[0].Z

                    polyseg1=l1.ComputePolySeg()
                    polyseg1=polyseg1.ToWorld()
                    polyseg1_v=l1.ComputeVerticalPolySeg()

                    polyseg1 = polyseg1.Linearize(0.0001, 0.0001, 10000.0, polyseg1_v, False)

                    # move polyseg over cloud center of gravity
                    polyseg1.Translate(polyseg1.FirstNode, polyseg1.LastNode, Vector3D(polyrefpoint, centerofcloud))
                    
                    # compute offsets from polyseg
                    outPointOnCL = clr.StrongBox[Point3D]()
                    outstation = clr.StrongBox[float]()
                    
                    ssd = 0 # sum of squared deviations

                    
                    # get sum of squared deviations
                    for i in range(0, cloudpoints.Count):
                        if polyseg1.FindPointFromPoint(cloudpoints[i], outPointOnCL, outstation):
                            p2 = outPointOnCL.Value
                            ssd += Vector3D(cloudpoints[i], p2).Length2D2

                    
                    # prepare inital values
                    dxdyspread = self.dxdyspread.Value
                    dxdystep = self.dxdystep.Value
                    bestcenter = Point3D(centerofcloud)
                    maxrot = self.maxrot.Value
                    rotstep = self.rotstep.Value
                    bestrot = 0.0

                    bestssd = ssd
                    polyrefpoint = Point3D(bestcenter)
                    
                    dxdydivider = self.dxdydivider.Value
                    rotdivider = self.rotdivider.Value
                    dxdybreak = self.dxdybreak.Value
                    rotbreak = self.rotbreak.Value

                    breakcond = False

                    while not breakcond:
                        # iterate(dxdyspread, dxdystep, maxrot in degrees, rotstep in degress previousbestcenter, previousbestssd, testpolyseg, cloudpoints):
                        iterate_result = self.iterate(dxdyspread, dxdystep, bestcenter, maxrot, rotstep, bestrot, bestssd, polyseg1, cloudpoints, wv)
                        bestssd = iterate_result[0]
                        # check if we reached the break condition
                        if dxdystep <= dxdybreak and rotstep <= rotbreak:
                            breakcond = True
                        # save result for next iteration
                        bestcenter = Point3D(iterate_result[1])
                        bestrot = iterate_result[2]
                        # move polyseg to best result
                        polyseg1.Translate(polyseg1.FirstNode, polyseg1.LastNode, Vector3D(polyrefpoint, bestcenter))
                        polyseg1.Rotate(bestcenter, bestrot)
                        polyrefpoint = Point3D(bestcenter)
                        #prepare for next iteration
                        dxdyspread /= dxdydivider
                        dxdystep /= dxdydivider
                        maxrot /= rotdivider
                        rotstep /= rotdivider

                        # 1
                    ## iterate(dxdyspread, dxdystep, maxrot in degrees, rotstep in degress previousbestcenter, previousbestssd, testpolyseg, cloudpoints):
                    #iterate_result = self.iterate(1, 0.1, bestcenter, 45, 7.5, bestrot, bestssd, polyseg1, cloudpoints, wv)
                    #bestssd = iterate_result[0]
                    #bestcenter = Point3D(iterate_result[1])
                    #bestrot = iterate_result[2]
                    ## move polyseg to best result
                    #polyseg1.Translate(polyseg1.FirstNode, polyseg1.LastNode, Vector3D(polyrefpoint, bestcenter))
                    #polyseg1.Rotate(bestcenter, bestrot)
                    #polyrefpoint = Point3D(bestcenter)
                    #
                    ## test draw result
                    ##cadPoint = wv.Add(clr.GetClrType(CadPoint))
                    ##cadPoint.Point0 = bestcenter
                    ##l = wv.Add(clr.GetClrType(Linestring))      # we start a new string line
                    ##l.Color = Color.Red
                    ##for i in range(0, polyseg1.NumberOfNodes):       # and add all nodes of the profile as new nodes of that string line
                    ##    drawpoint = polyseg1[i].Point    # we get the profile node coordinate into a temp point
                    ##    e = ElementFactory.Create(clr.GetClrType(IStraightSegment), clr.GetClrType(IXYZLocation))
                    ##    e.Position = drawpoint  # we draw that string line segment
                    ##    l.AppendElement(e)
                    #
                    ## 2
                    ## iterate(dxdyspread, dxdystep, previousbestcenter, previousbestssd, testpolyseg, cloudpoints):
                    #iterate_result = self.iterate(0.200, 0.020, bestcenter, 15, 3, bestrot, bestssd, polyseg1, cloudpoints, wv)
                    #bestssd = iterate_result[0]
                    #bestcenter = Point3D(iterate_result[1])
                    #bestrot = iterate_result[2]
                    ## move polyseg to best result
                    #polyseg1.Translate(polyseg1.FirstNode, polyseg1.LastNode, Vector3D(polyrefpoint, bestcenter))
                    #polyseg1.Rotate(bestcenter, bestrot)
                    #polyrefpoint = Point3D(bestcenter)
                    #
                    ## test draw result
                    ##cadPoint = wv.Add(clr.GetClrType(CadPoint))
                    ##cadPoint.Point0 = bestcenter
                    ##l = wv.Add(clr.GetClrType(Linestring))      # we start a new string line
                    ##l.Color = Color.Yellow
                    ##for i in range(0, polyseg1.NumberOfNodes):       # and add all nodes of the profile as new nodes of that string line
                    ##    drawpoint = polyseg1[i].Point    # we get the profile node coordinate into a temp point
                    ##    e = ElementFactory.Create(clr.GetClrType(IStraightSegment), clr.GetClrType(IXYZLocation))
                    ##    e.Position = drawpoint  # we draw that string line segment
                    ##    l.AppendElement(e)
                    #
                    ## 3
                    ## iterate(dxdyspread, dxdystep, previousbestcenter, previousbestssd, testpolyseg, cloudpoints):
                    #iterate_result = self.iterate(0.050, 0.005, bestcenter, 5, 1, bestrot, bestssd, polyseg1, cloudpoints, wv)
                    #bestssd = iterate_result[0]
                    #bestcenter = Point3D(iterate_result[1])
                    #bestrot = iterate_result[2]
                    ## move polyseg to best result
                    #polyseg1.Translate(polyseg1.FirstNode, polyseg1.LastNode, Vector3D(polyrefpoint, bestcenter))
                    #polyseg1.Rotate(bestcenter, bestrot)
                    #polyrefpoint = Point3D(bestcenter)
                    #
                    ## test draw result
                    ##cadPoint = wv.Add(clr.GetClrType(CadPoint))
                    ##cadPoint.Point0 = bestcenter
                    ##l = wv.Add(clr.GetClrType(Linestring))      # we start a new string line
                    ##l.Color = Color.Green
                    ##for i in range(0, polyseg1.NumberOfNodes):       # and add all nodes of the profile as new nodes of that string line
                    ##    drawpoint = polyseg1[i].Point    # we get the profile node coordinate into a temp point
                    ##    e = ElementFactory.Create(clr.GetClrType(IStraightSegment), clr.GetClrType(IXYZLocation))
                    ##    e.Position = drawpoint  # we draw that string line segment
                    ##    l.AppendElement(e)
                    #
                    ## 4
                    ## iterate(dxdyspread, dxdystep, previousbestcenter, previousbestssd, testpolyseg, cloudpoints):
                    #iterate_result = self.iterate(0.010, 0.001, bestcenter, 1, 0.1, bestrot, bestssd, polyseg1, cloudpoints, wv)
                    #bestssd = iterate_result[0]
                    #bestcenter = Point3D(iterate_result[1])
                    #bestrot = iterate_result[2]
                    ## move polyseg to best result
                    #polyseg1.Translate(polyseg1.FirstNode, polyseg1.LastNode, Vector3D(polyrefpoint, bestcenter))
                    #polyseg1.Rotate(bestcenter, bestrot)
                    #polyrefpoint = Point3D(bestcenter)


                    # test draw result
                    cadPoint = wv.Add(clr.GetClrType(CadPoint))
                    cadPoint.Point0 = bestcenter
                    cadPoint.Layer = self.layerpicker.SelectedSerialNumber

                    l = wv.Add(clr.GetClrType(Linestring))      # we start a new string line
                    l.Color = Color.Blue
                    for i in range(0, polyseg1.NumberOfNodes):       # and add all nodes of the profile as new nodes of that string line
                        drawpoint = polyseg1[i].Point    # we get the profile node coordinate into a temp point
                        e = ElementFactory.Create(clr.GetClrType(IStraightSegment), clr.GetClrType(IXYZLocation))
                        e.Position = drawpoint  # we draw that string line segment
                        l.AppendElement(e)
                    l.Layer = self.layerpicker.SelectedSerialNumber


                    failGuard.Commit()
                    UIEvents.RaiseAfterDataProcessing(self, UIEventArgs())
                    self.currentProject.TransactionManager.AddEndMark(CommandGranularity.Command)
        
            except Exception as e:
                tt = sys.exc_info()
                exc_type, exc_obj, exc_tb = sys.exc_info()
                # EndMark MUST be set no matter what
                # otherwise TBC won't work anymore and needs to be restarted
                self.currentProject.TransactionManager.AddEndMark(CommandGranularity.Command)
                UIEvents.RaiseAfterDataProcessing(self, UIEventArgs())
                self.error.Content += '\nan Error occurred - Result probably incomplete\n' + str(exc_type) + '\n' + str(exc_obj) + '\nLine ' + str(exc_tb.tb_lineno)

        ProgressBar.TBC_ProgressBar.Title = ""
        self.success.Content += '\n\nDone'
        self.SaveOptions()
        Keyboard.Focus(self.objs)

    def steprange(self, start, stop, step): # we have to create a step array ourselfs, python range doesn't support float values

        steprange = []

        while start <= stop:
            steprange.Add(start)
            start += step

        return steprange
    
    def iterate(self, dxdyspread, dxdystep, bestcenter, maxrot, rotstep, bestrot, bestssd, polyseg1, cloudpoints, wv):
        
      
        dxdylow = - abs(dxdyspread / 2.0)
        dxdyhigh = abs(dxdyspread / 2.0)
        dxdyrange = self.steprange(dxdylow, dxdyhigh, dxdystep)
        
        rotlow = - abs(maxrot / 2.0)
        rothigh = abs(maxrot / 2.0)
        mainrot = 0 # polyseg was already rotated after previous iteration
        rotrange = self.steprange(rotlow, rothigh, rotstep)

        testpolyseg = polyseg1.Clone()
    
        currenttestcenter = Point3D()
        previoustestcenter = Point3D(bestcenter)
        dxdycenter = Point3D(bestcenter)
    
        # compute offsets from polyseg
        outSegment = clr.StrongBox[Segment]()
        out_t = clr.StrongBox[float]()
        outPointOnCL = clr.StrongBox[Point3D]()
        outstation = clr.StrongBox[float]()
        perpVector3D = clr.StrongBox[Vector3D]()
        testDist = clr.StrongBox[float]()
        testside = clr.StrongBox[Side]()
        
        
        j = 0
        for dx in dxdyrange:
            j += 1
            if ProgressBar.TBC_ProgressBar.SetProgress(math.floor(j * 100 / dxdyrange.Count)):
                    break   # function returns true if user pressed cancel
    
            for dy in dxdyrange:
                
                currenttestcenter.X = dxdycenter.X + dx
                currenttestcenter.Y = dxdycenter.Y + dy
                currenttestcenter.Z = dxdycenter.Z
                
                # move polyseg over test center
                testpolyseg.Translate(testpolyseg.FirstNode, testpolyseg.LastNode, Vector3D(previoustestcenter, currenttestcenter))
                
                for currentrot in rotrange:
                    #rotate polyseg
                    currentrot = (currentrot * math.pi / 180) + mainrot
                    rottestpolyseg = testpolyseg.Clone() # create an internal copy each time and rotate that one
                    rottestpolyseg.Rotate(currenttestcenter, currentrot)
                    # test draw result
                    #cadPoint = wv.Add(clr.GetClrType(CadPoint))
                    #cadPoint.Point0 = currenttestcenter
                    #
                    #l = wv.Add(clr.GetClrType(Linestring))      # we start a new string line
                    #for i in range(0, rottestpolyseg.NumberOfNodes):       # and add all nodes of the profile as new nodes of that string line
                    #    drawpoint = rottestpolyseg[i].Point    # we get the profile node coordinate into a temp point
                    #    e = ElementFactory.Create(clr.GetClrType(IStraightSegment), clr.GetClrType(IXYZLocation))
                    #    e.Position = drawpoint  # we draw that string line segment
                    #    l.AppendElement(e)
    
                    # get sum of squared deviations
                    currentssd = 0
                    for i in range(0, cloudpoints.Count):
                        #if rottestpolyseg.FindPointFromPoint(cloudpoints[i], outSegment, out_t, outPointOnCL, outstation, perpVector3D, testDist, testside): 
                        if rottestpolyseg.FindPointFromPoint(cloudpoints[i], outPointOnCL, outstation):
                            p2 = outPointOnCL.Value
                            #ttt = testDist.Value
                            #if testside.Value == Side.Left: ttt *= -1
                            currentssd += Vector3D(cloudpoints[i], p2).Length2D2
                            #currentssd += ttt
    
                    # check if we got better
                    # ttt = round(currentssd,6)
                    if currentssd < bestssd:
                        bestssd = currentssd
                        bestcenter.X = currenttestcenter.X
                        bestcenter.Y = currenttestcenter.Y
                        bestcenter.Z = currenttestcenter.Z
                        bestrot = currentrot
    
                previoustestcenter.X = currenttestcenter.X
                previoustestcenter.Y = currenttestcenter.Y
                previoustestcenter.Z = currenttestcenter.Z
            
        return [bestssd, bestcenter, bestrot]
