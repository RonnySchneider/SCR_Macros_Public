#   GNU GPLv3
#   <this is an add-on Script/Macro for the geospatial software "Trimble Business Center" aka TBC>
#   <you'll need at least the "Survey Advanced" licence of TBC in order to run this script>
#	<see the ToolTip section below for a brief explanation what the script does>
#	<see the Help-Files for more details>
#   Copyright (C) 2023 Ronny Schneider
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <https://www.gnu.org/licenses/>

from System.Collections.Generic import List, IEnumerable # import here, otherwise there is a weird issue with Count and Add for lists
import os
execfile("C:\ProgramData\Trimble\MacroCommands\SCR Macros\SCR_Imports.py")

def Setup(cmdData, macroFileFolder):
    cmdData.Key = "SCR_MacroSync"
    cmdData.CommandName = "SCR_MacroSync"
    cmdData.Caption = "_SCR_MacroSync"
    cmdData.UIForm = "SCR_MacroSync"      # MUST MATCH NAME FROM CLASS DEFINED BELOW !!!
    cmdData.HelpFile = "Macros.chm"
    cmdData.HelpTopic = "22602"

    try:
        cmdData.DefaultTabKey = "SCR ImExport/DTM/Subgrade"
        cmdData.DefaultTabGroupKey = "Import/Export"
        cmdData.ShortCaption = "update SCR Macros from Server"
        cmdData.DefaultRibbonToolSize = 3 # Default=0, ImageOnly=1, Normal=2, Large=3
        cmdData.EnableNoProject = True

        cmdData.Version = 1.05
        cmdData.MacroAuthor = "SCR"
        cmdData.MacroInfo = r""
        
        cmdData.ToolTipTitle = "update SCR Macros from Server"
        cmdData.ToolTipTextFormatted = "update SCR Macros from Server"

    except:
        pass
    try:
        b = Bitmap (macroFileFolder + "\\" + cmdData.Key + ".png") 
        cmdData.ImageSmall = b
    except:
        pass


class SCR_MacroSync(StackPanel): # this inherits from the WPF StackPanel control
    def __init__(self, currentProject, macroFileFolder):
        with StreamReader (macroFileFolder + r"\SCR_MacroSync.xaml") as s:
            wpf.LoadComponent (self, s)
        self.currentProject = currentProject
        self.macroFileFolder = macroFileFolder

    def HelpClicked(self, cmd, e):
        webbrowser.open("C:\ProgramData\Trimble\MacroCommands\SCR Macros\MacroHelp\MacroHelp.htm#_" + type(self).__name__)


    def OnLoad(self, cmd, buttons, event):
        self.okBtn = buttons[0]
        buttons[2].Content = "Help"
        buttons[2].Visibility = Visibility.Visible
        buttons[2].Click += self.HelpClicked
        self.Caption = cmd.Command.Caption

		# after changing the input fields in a lot of macros from the old textboxes to floating point number or distance edits
		# it could happen that old settings, saved as strings, would throw a type cast error
		# hence it's better to have it in a try block
        try:
            self.SetDefaultOptions()
        except:
            pass

    def SetDefaultOptions(self):
        self.serverfolder.Text = OptionsManager.GetString("SCR_MacroSync.serverfolder", "Z:\\2790 - Software\\Trimble\\TBC\Macros\\SCR Macros V5.71")
        #self.localfolder.Text = OptionsManager.GetString("SCR_MacroSync.localfolder", "C:/ProgramData/Trimble/MacroCommands/SCR Macros")
        
    def SaveOptions(self):
        OptionsManager.SetValue("SCR_MacroSync.serverfolder", self.serverfolder.Text)
        #OptionsManager.SetValue("SCR_MacroSync.localfolder", self.localfolder.Text)

    def serverbutton_Click(self, sender, e):
        dialog = FolderBrowserDialog()
        dialog.SelectedPath = self.serverfolder.Text.replace("/", "\\")
        tt = dialog.ShowDialog()
        if tt==DialogResult.OK:
            self.serverfolder.Text = dialog.SelectedPath.replace("\\", "/")

    #def localbutton_Click(self, sender, e):
    #    dialog = FolderBrowserDialog()
    #    dialog.SelectedPath = self.localfolder.Text.replace("/", "\\")
    #    tt = dialog.ShowDialog()
    #    if tt==DialogResult.OK:
    #        self.localfolder.Text = dialog.SelectedPath.replace("\\", "/")

    def OkClicked(self, cmd, e):
        Keyboard.Focus(self.okBtn)
        self.error.Content = ""
        self.success.Content = ""

        # changed to hardcoded local folder in order to make the transition and maintance with V5.90-Python 3.4 easier
        # I don't want to delete my development folder and load old stuff from the server
        if "ronny" in os.path.expanduser('~/Downloads/'):
            self.localfolder = "C:/ProgramData/Trimble/MacroCommands/SyncTest"
        else:
            self.localfolder = "C:/ProgramData/Trimble/MacroCommands/SCR Macros"

        # only start deleting stuff if the target folder is within the standard Trimble Macro folder
        if "C:/ProgramData/Trimble/MacroCommands" in self.localfolder:
            
            self.success.Content += "\ndeleting old folder - " + self.localfolder
            try:
                shutil.rmtree(self.localfolder)
            except:
                pass

            self.success.Content += "\ncopying from Server now"
            shutil.copytree(self.serverfolder.Text, self.localfolder)
            
            self.success.Content += "\nRestart TBC now"

        else:

            self.error.Content += "\nlocal folder must be a subfolder in\n'C:/ProgramData/Trimble/MacroCommands'"

        self.SaveOptions()